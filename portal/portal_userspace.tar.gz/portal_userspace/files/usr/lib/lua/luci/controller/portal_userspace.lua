module("luci.controller.portal_userspace", package.seeall)

function index()
	entry({"admin", "app", "portal_userspace"}, cbi("portal_userspaceconfig"), _("portal_userspace Config"), 110)
end
