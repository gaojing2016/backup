--[[
LuCI - Lua Configuration Interface - Aria2 support

Copyright 2014 nanpuyue <nanpuyue@gmail.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0
]]--

require("luci.sys")
require("luci.util")
require("nixio.fs")

local fs = require "nixio.fs"


m = Map("portal_userspace", translate("portal==="), translate(""))

s=m:section(TypedSection, "portal_userspace", translate(""))
s.anonymous=true                                                        
s.addremove=fals

freemac = s:option(value, "freemac", translate("kksk"))
freemac.placeholder = ""
local apply = luci.http.formvalue("cbi.apply")
if apply then
	io.popen("/etc/init.d/portal_userspace restart")
return m
