#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/socket.h>     /* for AF_NETLINK */
#include <sys/ioctl.h>      /* for ioctl */
#include <linux/netlink.h>  /* for sockaddr_nl */
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//#include "extnetlink.h"
//#include "usermanagement.h"
#include "struct_data.h"

#define RET_INIT 0
#define RET_SUCCESS 1
#define RET_FAIL -1
#define PORTAL_DEVICE_NAME  "/dev/portal"

/* ============================== board func start =====================================*/

char ap_serial_number[20] = {0};
int skbmark = 0;
int devCtl_portalIoctl(unsigned int portal_ioctl,
        PORTAL_IOCTL_ACTION action,
        char *string,
        int strLen,
        int offset,
        void *data);


//********************************************************************************************
// misc. ioctl calls come to here. (flash, led, reset, kernel memory access, etc.)
//********************************************************************************************

int devCtl_portalIoctl(unsigned int portal_ioctl,
        PORTAL_IOCTL_ACTION action,
        char *string,
        int strLen,
        int offset,
        void *data)
{
    PORTAL_IOCTL_PARMS ioctlParms;
    int portalFd = 0;
    int rc;
    int ret = RET_INIT;

    portalFd = open(PORTAL_DEVICE_NAME, O_RDWR);

    if ( portalFd != -1 )
    {
        ioctlParms.string = string;
        ioctlParms.strLen = strLen;
        ioctlParms.offset = offset;
        ioctlParms.action = action;
        ioctlParms.buf    = data;
        ioctlParms.result = -1;

        rc = ioctl(portalFd, portal_ioctl, &ioctlParms);
        close(portalFd);
        ret = RET_SUCCESS;

        if (rc < 0)
        {
            printf("portal_ioctl =0x%x action=%d rc=%d err = %s\n", portal_ioctl, action, rc, strerror(errno));
            ret = -1;
        }
    }
    else
    {
        printf("Unable to open device %s", PORTAL_DEVICE_NAME);
        ret = RET_FAIL;
    }

    return ret;
}

void devctl_get_portal_info(void);
void devctl_get_portal_info_update(void);
void portal_get_portal_info_update(struct portal_info *portal_info_temp_list);
void portal_get_portal_info(struct portal_group *portal_group_temp_list);
int devctl_set_portalurl(const int skb_mark, char *portalurl_buf);
int devctl_set_freeurl(const int skb_mark, char *freeurl_buf);
int devctl_set_freemac(const int skb_mark, char *freemac_buf);
int devctl_set_iphoneurl(char *iphoneurl_buf);
int devctl_set_weixinurl(const int skb_mark, char *weixinurl_buf);
int devctl_set_weixinportalurl(const int skb_mark, char *weixinportalurl_buf);
void portal_ebtables_set_mark(char *dev_name);

void devctl_get_portal_info_update(void)
{
    //printf("%s[%d]: Enter\n", __func__, __LINE__);
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    struct portal_info portal_info_list;
    memset( &portal_info_list, 0, sizeof(portal_info_list));
    //memset(portal_info_list.portal_group_list_info, 0, sizeof(portal_info_list.portal_group_list_info));

    portal_get_portal_info_update(&portal_info_list);

    for ( m = 0; m < MAX_IPHONE_URL_LIST_NUM; m ++)
    {
        if ( '\0' != portal_info_list.iphoneurl[m][0])
        {
            printf("##############iphoneurl[%d] = %s\n", m, portal_info_list.iphoneurl[m]);
        }
    }

    for ( i = 0; i < LAN_DEV_NUM; i++)
    {
        printf("portal_group_list[%d] info:\n", i);

        if ( '\0' != portal_info_list.portal_group_list_info[i].portalurl[0])
        {
            printf("portal_group_list[%d].portalurl=%s\n", i, portal_info_list.portal_group_list_info[i].portalurl);
        }

        if ( '\0' != portal_info_list.portal_group_list_info[i].redirecturl[0])
        {
            printf("portal_group_list[%d].redirecturl=%s\n", i, portal_info_list.portal_group_list_info[i].redirecturl);
        }

        if ( '\0' != portal_info_list.portal_group_list_info[i].weixinurl[0])
        {
            printf("portal_group_list[%d].weixinurl=%s\n", i, portal_info_list.portal_group_list_info[i].weixinurl);
        }

        if ( '\0' != portal_info_list.portal_group_list_info[i].weixinportalurl[0])
        {
            printf("portal_group_list[%d].weixinportalurl=%s\n", i, portal_info_list.portal_group_list_info[i].weixinportalurl);
        }

        for (j = 0; j < MAX_FREE_URL_LIST_NUM; j ++)
        {
            if ( '\0' != portal_info_list.portal_group_list_info[i].freeurl[j][0])
            {
                printf("portal_group_list[%d].freeurl[%d]=%s\n", i, j, portal_info_list.portal_group_list_info[i].freeurl[j]);
            }
        }

        for( k = 0; k < MAX_FREE_MAC_LIST_NUM; k ++)
        {
            if ( '\0' != portal_info_list.portal_group_list_info[i].freemac[k][0])
            {
                printf("portal_group_list[%d].freemac[%d]=%s\n", i, k, portal_info_list.portal_group_list_info[i].freemac[k]);
            }
        }

    }

    //printf("%s[%d]: Exit\n", __func__, __LINE__);
    return;

}

void portal_get_portal_info_update(struct portal_info *portal_info_temp_list)
{
    return(devCtl_portalIoctl(PORTAL_IOCTL_GET_PORTAL_INFO_UPDATE,
                0,
                (char *)portal_info_temp_list,
                (sizeof(struct portal_info)),
                0,
                ""));
}

void devctl_get_portal_info(void)
{
    //printf("%s[%d]: Enter\n", __func__, __LINE__);
    int i = 0;
    int j = 0;
    int k = 0;
    struct portal_group portal_group_list[LAN_DEV_NUM];
    char temp_macbuf[MAX_MAC_LEN] = {0};
    memset(portal_group_list, 0, sizeof(portal_group_list));

    portal_get_portal_info(portal_group_list);

    printf("\n");
    printf("\n");

    for ( i = 0; i < LAN_DEV_NUM; i++)
    {
        printf(" portal_group_list[%d] info:\n", i);

        if ( '\0' != portal_group_list[i].portalurl[0])
        {
            printf("portal_group_list[%d].portalurl=%s\n", i, portal_group_list[i].portalurl);
        }

        if ( '\0' != portal_group_list[i].redirecturl[0])
        {
            printf("portal_group_list[%d].redirecturl=%s\n", i, portal_group_list[i].redirecturl);
        }

        if ( '\0' != portal_group_list[i].weixinurl[0])
        {
            printf("portal_group_list[%d].weixinurl=%s\n", i, portal_group_list[i].weixinurl);
        }

        if ( '\0' != portal_group_list[i].weixinportalurl[0])
        {
            printf("portal_group_list[%d].weixinportalurl=%s\n", i, portal_group_list[i].weixinportalurl);
        }

        for (j = 0; j < MAX_FREE_URL_LIST_NUM; j ++)
        {
            if ( '\0' != portal_group_list[i].freeurl[j][0])
            {
                printf("portal_group_list[%d].freeurl[%d]=%s\n", i, j, portal_group_list[i].freeurl[j]);
            }
        }

        for( k = 0; k < MAX_FREE_MAC_LIST_NUM; k ++)
        {
            if ( '\0' != portal_group_list[i].freemac[k][0])
            {
                printf("portal_group_list[%d].freemac[%d]=%s\n", i, k, portal_group_list[i].freemac[k]);
            }
        }

    }

    //printf("%s[%d]: Exit\n", __func__, __LINE__);
    return;

}

void portal_get_portal_info(struct portal_group *portal_group_temp_list)
{
    return(devCtl_portalIoctl(PORTAL_IOCTL_GET_PORTAL_INFO,
                0,
                (char *)portal_group_temp_list,
                (sizeof(struct portal_group) * LAN_DEV_NUM),
                0,
                ""));
}

int devctl_set_freeurl( const int skb_mark, char *freeurl_buf)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    //gaojing start 2016.01.04
    char *url = NULL;
    char freeurl_update_buf[MAX_FREE_URL_LIST_NUM][MAX_URL_LEN] = {0};
    int i = 0;
    struct freeurl_list freeurl_msg;
    memset(&freeurl_msg, 0, sizeof(freeurl_msg) );

    if(skb_mark < 1)
    {
        printf("skb_mark %d is invalid for portal\n", skb_mark);
        return -1;
    }

    if( NULL == freeurl_buf)
    {
        printf("freeurlbuf if NULL, no need to set, so return\n");
        return -1;
    }

    while( ( url = strsep(&freeurl_buf,";")) != NULL)
    {
        if (i > MAX_FREE_URL_LIST_NUM -1)
        {
            printf("can't save so many records because freeurl list is larger than %d\n", MAX_FREE_URL_LIST_NUM);
            return -1;
        }

        if ( strlen(url) > MAX_URL_LEN - 1)
        {
            printf("drop this record because it is longer than %d bytes\n", MAX_URL_LEN);
            continue;
        }

        /* gaojing change "*.baidu.* "to baidu" start*/
        if( '*' == url[strlen(url) - 1] )
        {
            url[strlen(url) - 1] = '\0';
        }

        if( '.' == url[strlen(url) - 1] )
        {
            url[strlen(url) - 1] = '\0';
        }


        if ( ('*' == url[0]) && ('.' == url[1]) )
        {
            memcpy(freeurl_update_buf[i], &url[2], MAX_URL_LEN-3);
        }

        else if  ( ('*' == url[0]) && ('.' != url[1]) )
        {
            memcpy(freeurl_update_buf[i], &url[1], MAX_URL_LEN-2);
        }

        else
        {
            memcpy(freeurl_update_buf[i], url, MAX_URL_LEN-1);
        }

        freeurl_update_buf[i][MAX_URL_LEN-1] = '\0';
        i ++;
        /* gaojing change "*.baidu.* "to baidu" end*/

    }
    //gaojing end 2015.01.04

    freeurl_msg.groupid = skb_mark - 1;
    memcpy( freeurl_msg.freeurl, freeurl_update_buf, sizeof(freeurl_msg.freeurl));

    devCtl_portalIoctl(PORTAL_IOCTL_SET_FREE_URL,
            0,
            (char *)&freeurl_msg,
            (sizeof(freeurl_msg)),
            0,
            "");

    //printf("%s[%d]: Exit \n", __func__, __LINE__);
    return 0;
}

int devctl_set_iphoneurl(char *iphoneurl_buf)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    //add by gaojing start 2016.01.04
    char *url = NULL;
    char iphoneurl_update_buf[MAX_IPHONE_URL_LIST_NUM][MAX_URL_LEN] = {0};
    int i = 0;
    struct iphoneurl_list iphoneurl_msg;
    memset(&iphoneurl_msg, 0, sizeof(iphoneurl_msg) );

    if( NULL == iphoneurl_buf)
    {
        printf("iphoneurlbuf if NULL, no need to set, so return\n");
        return -1;
    }

    while( ( url = strsep(&iphoneurl_buf,";")) != NULL)
    {
        if (i > MAX_IPHONE_URL_LIST_NUM -1)
        {
            printf("can't save so many records because freeurl list is larger than %d\n", MAX_FREE_URL_LIST_NUM);
            return -1;
        }

        if ( strlen(url) > MAX_URL_LEN - 1)
        {
            printf("drop this record because it is longer than %d bytes\n", MAX_URL_LEN);
            continue;
        }

        /* gaojing change "*.baidu.* "to baidu" start*/
        if( '*' == url[strlen(url) - 1] )
        {
            url[strlen(url) - 1] = '\0';
        }

        if( '.' == url[strlen(url) - 1] )
        {
            url[strlen(url) - 1] = '\0';
        }


        if ( ('*' == url[0]) && ('.' == url[1]) )
        {
            memcpy(iphoneurl_update_buf[i], &url[2], MAX_URL_LEN-3);
        }

        else if  ( ('*' == url[0]) && ('.' != url[1]) )
        {
            memcpy(iphoneurl_update_buf[i], &url[1], MAX_URL_LEN-2);
        }

        else
        {
            memcpy(iphoneurl_update_buf[i], url, MAX_URL_LEN-1);
        }

        iphoneurl_update_buf[i][MAX_URL_LEN-1] = '\0';

        //printf("user test url[%d]=%s, iphoneurl_update_buf[%d]=%s\n", i, url, i, iphoneurl_update_buf[i]);

        i ++;
        /* gaojing change "*.baidu.* "to baidu" end*/

    }
    // add by gaojing end 2015.01.04

    memcpy( iphoneurl_msg.iphoneurl, iphoneurl_update_buf, sizeof(iphoneurl_msg.iphoneurl));


    devCtl_portalIoctl(PORTAL_IOCTL_SET_IPHONE_URL,
            0,
            (char *)&iphoneurl_msg,
            (sizeof(iphoneurl_msg)),
            0,
            "");

    //printf("%s[%d]: Exit \n", __func__, __LINE__);

}


int devctl_set_portalurl(const int skb_mark, char *portalurl_buf)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    struct portalurl_list portalurl_msg;
    char portalurl_buf_update[MAX_URL_LEN] = {0};
    memset(&portalurl_msg, 0, sizeof(portalurl_msg) );

    if(skb_mark < 1)
    {
        printf("skb_mark %d is invalid for portal\n", skb_mark);
        return -1;
    }

    if(( NULL == portalurl_buf) || ( NULL == strstr( portalurl_buf, ".") ) )
    {
        printf("portalurl_buf is NULL or invalid, no need to set, so return\n");
        return -1;
    }

    if( NULL == strchr(portalurl_buf,'?') )
    {
        snprintf( portalurl_buf_update, sizeof(portalurl_buf_update), "%s?routersn=%s", portalurl_buf, ap_serial_number);
    }

    else
    {
        snprintf( portalurl_buf_update, sizeof(portalurl_buf_update), "%s&routersn=%s", portalurl_buf, ap_serial_number);
    }

    portalurl_buf_update[MAX_URL_LEN -1 ] = '\0';
    portalurl_msg.groupid = skb_mark - 1;
    memcpy( portalurl_msg.portalurl, portalurl_buf_update, sizeof(portalurl_msg.portalurl));

    devCtl_portalIoctl(PORTAL_IOCTL_SET_PORTAL_URL,
            0,
            (char *)&portalurl_msg,
            (sizeof(portalurl_msg)),
            0,
            "");
    //printf("%s[%d]: Exit \n", __func__, __LINE__);
    return 0;
}

int devctl_set_weixinurl(const int skb_mark, char *weixinurl_buf)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    struct weixinurl_list weixinurl_msg;
    memset(&weixinurl_msg, 0, sizeof(weixinurl_msg) );

    if(skb_mark < 1)
    {
        printf("skb_mark %d is invalid for portal\n", skb_mark);
        return -1;
    }

    if( ( NULL == weixinurl_buf) || (NULL == strstr(weixinurl_buf, ".")) )
    {
        printf("weixinurl_buf is NULL or invalid, no need to set, so return\n");
        return -1;
    }

    weixinurl_msg.groupid = skb_mark - 1;
    memcpy( weixinurl_msg.weixinurl, weixinurl_buf, sizeof(weixinurl_msg.weixinurl));

    devCtl_portalIoctl(PORTAL_IOCTL_SET_WEIXIN_URL,
            0,
            (char *)&weixinurl_msg,
            (sizeof(weixinurl_msg)),
            0,
            "");
    //printf("%s[%d]: Exit \n", __func__, __LINE__);
    return 0;
}

int devctl_set_weixinportalurl(const int skb_mark, char *weixinportalurl_buf)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    struct weixinportalurl_list weixinportalurl_msg;
    memset(&weixinportalurl_msg, 0, sizeof(weixinportalurl_msg) );

    if(skb_mark < 1)
    {
        printf("skb_mark %d is invalid for portal\n", skb_mark);
        return -1;
    }

    if( ( NULL == weixinportalurl_buf) || (NULL == strstr( weixinportalurl_buf, ".")) )
    {
        printf("weixinurl_buf is NULL or invalid, no need to set, so return\n");
        return -1;
    }

    weixinportalurl_msg.groupid = skb_mark - 1;
    memcpy( weixinportalurl_msg.weixinportalurl, weixinportalurl_buf, sizeof(weixinportalurl_msg.weixinportalurl));

    devCtl_portalIoctl(PORTAL_IOCTL_SET_WEIXIN_PORTAL_URL,
            0,
            (char *)&weixinportalurl_msg,
            (sizeof(weixinportalurl_msg)),
            0,
            "");
    //printf("%s[%d]: Exit \n", __func__, __LINE__);
    return 0;

}


int devctl_set_freemac(const int skb_mark, char *freemac_buf)
{
    //printf("%s[%d]: Enter\n", __func__, __LINE__);

    //gaojing start 2015.01.04
    char *mac = NULL;
    char freemac_update_buf[MAX_FREE_MAC_LIST_NUM][MAX_MAC_LEN] = {0};
    int i = 0;
    struct freemac_list freemac_msg;
    memset(&freemac_msg, 0, sizeof(freemac_msg) );

    if(skb_mark < 1)
    {
        printf("skb_mark %d is invalid for portal\n", skb_mark);
        return -1;
    }

    if( NULL == freemac_buf)
    {
        printf("freemac_buf if NULL, no need to set, so return\n");
        return -1;
    }

    while( ( mac = strsep(&freemac_buf,";")) != NULL) 
    {   
        if ( i > MAX_FREE_MAC_LIST_NUM -1)
        {
            printf(" Can't save so many records because freemac list is larger than %d\n", MAX_FREE_MAC_LIST_NUM);
            return -1; 
        }

        if ( ( 0 == strcmp("", mac)) || (strlen(mac) > MAX_MAC_LEN - 1) )
        {
            printf("drop this freemac record because it is invalid\n");
            continue; 
        }

        memcpy(freemac_update_buf[i], mac, MAX_MAC_LEN-1 );
        freemac_update_buf[i][MAX_MAC_LEN-1] = '\0';
        //printf("mac is %s, freemac_update_buf[%d] is %s\n", mac, i, freemac_update_buf[i]);
        i ++; 

    }   
    //gaojing end 2015.01.04

    freemac_msg.groupid = skb_mark - 1;
    memcpy( freemac_msg.freemac, freemac_update_buf, sizeof(freemac_msg.freemac));


    devCtl_portalIoctl(PORTAL_IOCTL_SET_FREE_MAC,
            0,
            (char *)&freemac_msg,
            (sizeof(freemac_msg)),
            0,
            "");

    //printf("%s[%d]: Exit\n", __func__, __LINE__);
    return 0;
}

void portal_ebtables_set_mark(char *dev_name)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    char cmd1[128] = {0};
    char cmd2[128] = {0};
    FILE *fptr;
    char buf[128] = {0};

    if ((fptr = fopen("/etc/config/portal_conf", "r")) == NULL)
    {    
        perror("faile to open file /etc/config/portal_conf\n ");
        return ; 
    }   

    while(0 != fgets(buf, sizeof(buf)-1, fptr))
    {   
        printf("buf=%s\n", buf);
        if( ( NULL != strstr(buf, dev_name))) 
        {
            printf("interface=%s\n", dev_name);
            sscanf( buf, "%d ", &skbmark);
            printf("skbmark = %d\n",skbmark);
        }
    }   
    fclose(fptr);


    snprintf(cmd1, sizeof(cmd1), "ebtables -t broute -D BROUTING -i %s -j mark --mark-or 0x%d", dev_name, skbmark );
    printf("cmd1=%s\n", cmd1);
    system(cmd1);

    snprintf(cmd2, sizeof(cmd2), "ebtables -t broute -A BROUTING -i %s -j mark --mark-or 0x%d", dev_name, skbmark );
    printf("cmd2=%s\n", cmd2);
    system(cmd2);
    //printf("%s[%d]: Exit \n", __func__, __LINE__);

    return;

}

/* ======================== board func end  ============================ */

int portal_device_mknode_init(void);

void portal_init(void);

void get_ap_serial_number(void);

void portal_main(void);

int portal_device_mknode_init(void)
{
    FILE *fs = NULL;
    char line[255] = {0};
    char portal_name[50] = {0};
    char cmd_line[255] = {0};

    unsigned char portal_device_found_uch = 0;

    int portal_major = 0;
    char *portal_str = NULL;

    system("cat /proc/devices >/var/portal_devices.conf");
    system("chmod 777 /var/portal_devices.conf");

    if ((fs = fopen("/var/portal_devices.conf", "r")) != NULL) 
    {   
        memset(line,0,sizeof(line));

        while (fgets(line, 253, fs) != NULL) 
        {   
            if ( NULL != (portal_str = strstr(line, "portal"))) 
            {   
                printf("line = %s\n", line);
                *portal_str = '\0';
                printf("line = %s\n", line);
                portal_major = atoi(line);
                printf("portal_major = %d\n", portal_major);

                portal_device_found_uch = 1;

                break;
            }   
        }   

        fclose(fs);
    }   
    else
    {   
        printf("fopen portal_devices error, %s, insmod portal ko first ?\n",strerror(errno)); 

        return -1;
    }   

    if ( 0 == portal_device_found_uch)
    {
        printf("portal device not found\n");
        return -1;
    }


    system("rm -rf /dev/portal");

    snprintf(cmd_line, sizeof(cmd_line), "mknod /dev/portal c %d 0", portal_major);
    //printf("cmd_line = %s\n", cmd_line);
    system(cmd_line);
    /* to see, detect device create successfullly */
    return 0;
}

void portal_main(void)
{
    //printf("%s[%d]: Enter \n", __func__, __LINE__);
    char *interface = "ra0";
    char *update_freeurl = strdup("*.baidu.*;;*sina*;*img*;*qq*;*163*;*wechat.*");         
    char *update_freemac = strdup("F0:DB:E2:93:40:A2;;ff:d1:22:33:44:55;aa:bb:cc:dd:ee:ff");        
    char *update_portalurl = "www.163.com";                           
    char *update_weixinurl = "support.weixin.qq.com";                           
    char *update_weixinportalurl = "phitown.phicloud.com/phone/qrPage.do";                           
    char *update_iphoneurl = strdup("*apple*;;*captive.apple.con;*ibook.info;;;*itools.info;*airport.us");

    portal_ebtables_set_mark(interface);
    devctl_set_portalurl(skbmark, update_portalurl);
    devctl_set_freeurl(skbmark, update_freeurl);
    devctl_set_freemac(skbmark, update_freemac);
    devctl_set_iphoneurl(update_iphoneurl);
    devctl_set_weixinurl(skbmark, update_weixinurl);
    devctl_set_weixinportalurl(skbmark, update_weixinportalurl);
	devctl_get_portal_info_update();
    devctl_get_portal_info();

    return;

}

void get_ap_serial_number(void)
{
    //need to get apsn for portal url
    char *apsn = "00:11:22:33:44:55";
    memcpy( ap_serial_number, apsn, sizeof(ap_serial_number));
}

void portal_init(void)
{
    //printf("Enter %s\n", __func__);

    if ( 0 != portal_device_mknode_init())
    {
        printf("portal device init failed!\n");
        return;
    }

    get_ap_serial_number();

    //printf("Exit %s\n", __func__);

    return;
}

int main(int argc, char *argv[])
{
    portal_init();
    portal_main();

    return 0;
}
