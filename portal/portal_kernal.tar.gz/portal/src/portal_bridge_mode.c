#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <net/tcp.h>
#include <linux/netfilter_ipv4.h>
#include <linux/netfilter_bridge.h>
#include <linux/if_bridge.h>
#include "br_private.h"
#include "url_redirect_b.h"
//#include "struct_data.h"
//#include "usermanagement.h"
#include <linux/init.h>
#include <linux/module.h>
#include <linux/version.h>                /* for LINUX_VERSION_CODE */
#include <linux/fs.h>                     /* for struct file */
#include <linux/slab.h>                   /* for kmalloc, kfree */
#include <linux/cdev.h>
#include <uapi/asm-generic/ioctl.h>       /* for _IOC */
#include <linux/string.h>
#include "struct_data.h"
//#include "usermanagement.h"

/* =====================public start =======================  */

struct portal_group portal_group_list[LAN_DEV_NUM];
int g_group_id = - 1;

int (*portal_isfreeurl_hook)(const int skb_mark, const char* url);
int (*portal_isfreemac_hook)(const int skb_mark, const char *mac );
int (*portal_isAuthMac_hook)(const int skb_mark, const char *mac );
void (*portal_getRedirectUrl_hook)(const int skb_mark, char *url);
void (*portal_setMacSite_hook)(const int skb_mark, char *url);
void (*portal_getWeixinUrl_hook)(const int skb_mark, char *url);
void (*portal_getWeixinPortalUrl_hook)(const int skb_mark, char *url);
//int (*portal_isDip_LanIp_hook)(unsigned int dip);

int portal_isFreeurl(const int skb_mark, const char *url);
int portal_isFreemac(const int skb_mark, const char *mac);
int portal_isAuthMac(const int skb_mark, const char *mac);
void portal_getRedirectUrl(const int skb_mark, char *url);
void portal_setRedirectUrl(const int skb_mark, char *url);
void portal_getWeixinUrl(const int skb_mark, char *url);
void portal_getWeixinPortalUrl(const int skb_mark, char *url);

//int portal_isDip_LanIp(unsigned int dip);

#if 0
spinlock_t freeurl_lock;
spinlock_t freemac_lock;
#endif

int portal_isFreeurl(const int skb_mark, const char *url)
{
    int groupid = 0;
    int i = 0;
    int ret = -1;
    char urlbuf[MAX_URL_LEN]={0};

    if(skb_mark < 1)
    {
        printk("The skb_mark is invalid for portal, please check your code\n");
        return -1;
    }

    groupid = skb_mark - 1;

    if ((NULL == url) || (strlen(url) > MAX_URL_LEN-1))
    {    
        printk("the check url length is too large(%d)\n", strlen(url));
        return -1; 
    }    

    memcpy(urlbuf, url, MAX_URL_LEN - 1);
    urlbuf[MAX_URL_LEN-1] = '\0';

    for( i = 0; i < MAX_FREE_URL_LIST_NUM; i ++)
    {
        if ( '\0' == portal_group_list[groupid].freeurl[i][0])
        {
            return -1;
        }

        if  (NULL != strstr( urlbuf, portal_group_list[groupid].freeurl[i]))  
        {
            //printk("why are you here??\n");
            ret = 0;
            break;
        }

    }
    return ret;
}

int portal_isFreemac(const int skb_mark, const char *mac)
{
    int groupid = 0;
    int i = 0;
    int ret = -1;

    if(skb_mark < 1)
    {
        printk("The skb_mark is invalid for portal, please check your code\n");
        return -1;
    }

    groupid = skb_mark - 1;

    if (NULL == mac)
    {    
        printk("the mac value is invalid, plese check your code\n");
        return -1; 
    }    

    for( i = 0; i < MAX_FREE_MAC_LIST_NUM; i ++)
    {
        if ( '\0' == portal_group_list[groupid].freemac[i][0])
        {
            return -1;
        }

        if ( 0 == strncasecmp( portal_group_list[groupid].freemac[i], mac, MAX_MAC_LEN))
        {
            ret = 0;
            break;
        }
    }
    return ret;
}

//gaojing: waiting for usrmgmt to add ===
int portal_isAuthMac(const int skb_mark, const char *mac)
{
    return -1;
}

void portal_getRedirectUrl(const int skb_mark, char *url)
{
    int groupid = 0;

    if(skb_mark < 1)
    {
        printk("The skb_mark is invalid for portal, please check your code\n");
        return;
    }

    groupid = skb_mark - 1;

    if ( '\0' == portal_group_list[groupid].redirecturl[0])
    {
        return;
    }

    memcpy(url, portal_group_list[groupid].redirecturl, MAX_URL_LEN - 1);
    url[MAX_URL_LEN-1] = '\0';
    //printk("%s[%d]: Exit ===\n", __func__, __LINE__);

    return;

}

void portal_getWeixinUrl(const int skb_mark, char *url)
{
    int groupid = 0;

    if(skb_mark < 1)
    {
        printk("The skb_mark is invalid for portal, please check your code\n");
        return;
    }

    groupid = skb_mark - 1;

    if ( '\0' == portal_group_list[groupid].weixinurl[0])
    {
        return;
    }

    memcpy(url, portal_group_list[groupid].weixinurl, MAX_URL_LEN - 1);
    url[MAX_URL_LEN-1] = '\0';
    //printk("%s[%d]: Exit ===\n", __func__, __LINE__);

    return;

}

void portal_getWeixinPortalUrl(const int skb_mark, char *url)
{
    int groupid = 0;

    if(skb_mark < 1)
    {
        printk("The skb_mark is invalid for portal, please check your code\n");
        return;
    }

    groupid = skb_mark - 1;

    if ( '\0' == portal_group_list[groupid].weixinportalurl[0])
    {
        return;
    }

    memcpy(url, portal_group_list[groupid].weixinportalurl, MAX_URL_LEN - 1);
    url[MAX_URL_LEN-1] = '\0';
    //printk("%s[%d]: Exit ===\n", __func__, __LINE__);

    return;

}


void portal_setRedirectUrl(const int skb_mark, char *url)
{
    int groupid = 0;

    if(skb_mark < 1)
    {
        printk("The skb_mark is invalid for portal, please check your code\n");
        return ;
    }

    groupid = skb_mark - 1;

    if(NULL == url)
    {
        //printk("the redirect url is NULL, no need to set newredirectlurl again. skb_mark is %d!\n", skb_mark);
        return;
    }


    if ( '\0' == portal_group_list[groupid].portalurl[0])
    {
        //printk("portalurl is null, no need to portal, so no need to handle this function\n");
        return;
    }

    snprintf(portal_group_list[groupid].redirecturl, MAX_URL_LEN - 1, "%s%s", portal_group_list[groupid].portalurl, url);

    return;
}

#if 0
//no need to decide dip is lanip, since we use skb->mark to decide
int portal_isDip_LanIp(unsigned int dip)
{
    return 0;
}
#endif

/* ============================================================ */
/* Typedefs. */
typedef struct
{
    unsigned long eventmask;
} PORTAL_IOC;


/* Prototypes. */
static int portal_open( struct inode *inode, struct file *filp );
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,35)
static int portal_ioctl(struct file *filp, unsigned int command, unsigned long arg);
#else
static int portal_ioctl(struct inode *inode, struct file *flip, unsigned int command, unsigned long arg);
#endif
static ssize_t portal_read(struct file *filp,  char __user *buffer, size_t count, loff_t *ppos);
static unsigned int portal_poll(struct file *filp, struct poll_table_struct *wait);
static int portal_release(struct inode *inode, struct file *filp);

int portal_major = 0;

struct cdev portal_cdev;

static PORTAL_IOC* portal_ioc_alloc(void)
{
    PORTAL_IOC *portal_ioc = NULL;
    portal_ioc = (PORTAL_IOC*)kmalloc(sizeof(PORTAL_IOC), GFP_KERNEL);

    if(portal_ioc)
    {
        memset(portal_ioc, 0, sizeof(PORTAL_IOC));
    }

    return portal_ioc;
}

static int portal_open( struct inode *inode, struct file *filp )
{
    filp->private_data = portal_ioc_alloc();

    if( NULL == filp->private_data)
    {
        return -ENOMEM;
    }

    return 0;
}


static void portal_ioc_free(PORTAL_IOC* portal_ioc)
{
    if(portal_ioc)
    {
        kfree(portal_ioc);
    }

    return;
}

static int portal_release(struct inode *inode, struct file *filp)
{
    PORTAL_IOC *portal_ioc = filp->private_data;
    portal_ioc_free(portal_ioc);

    return 0;
}

static unsigned int portal_poll(struct file *filp, struct poll_table_struct *wait)
{
    return 0;
}

static ssize_t portal_read(struct file *filp, char __user *buffer, size_t count, loff_t *ppos)
{
    return 0;
}


//********************************************************************************************
// misc. ioctl calls come to here. (flash, led, reset, kernel memory access, etc.)
//********************************************************************************************

void portal_getPortalInfoRule(char *buf)
{
        memcpy(buf, portal_group_list, sizeof(portal_group_list));
}

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,35)
static int portal_ioctl(struct file *filp, unsigned int command, unsigned long arg)
#else
static int portal_ioctl( struct inode *inode, struct file *flip, unsigned int command, unsigned long arg )
#endif
{
    int ret = 0; 
    PORTAL_IOCTL_PARMS ctrlParms;

    switch (command)
    {

        case PORTAL_IOCTL_GET_PORTAL_INFO:
            {
                printk("PORTAL_IOCTL_GET_PORTAL_INFO\n");
                if (copy_from_user((void*)&ctrlParms, (void*)arg, sizeof(ctrlParms)) == 0)
                {
                    portal_getPortalInfoRule(ctrlParms.string);
                    ctrlParms.result = ret;
                    __copy_to_user((PORTAL_IOCTL_PARMS*)arg, &ctrlParms, sizeof(PORTAL_IOCTL_PARMS));
                }
                break;
            }

        case PORTAL_IOCTL_SET_PORTAL_URL:
            {
                printk("PORTAL_IOCTL_SET_PORTAL_URL\n");
                if (copy_from_user((void*)&ctrlParms, (void*)arg, sizeof(ctrlParms)) == 0)
                {
                    struct portalurl_list *portalurl_msg = NULL;
                    portalurl_msg = (struct portalurl_list *) ctrlParms.string;

                    if( NULL == portalurl_msg)
                    {
                        return -1;
                    }

                    g_group_id = portalurl_msg->groupid;
                    memset(portal_group_list[g_group_id].portalurl, 0, sizeof(portal_group_list[g_group_id].portalurl)); //gaojing
                    memcpy(portal_group_list[g_group_id].portalurl ,portalurl_msg->portalurl, sizeof(portal_group_list[g_group_id].portalurl));
                    printk("portal_group_list[%d].portalurl=%s\n", g_group_id, portal_group_list[g_group_id].portalurl); //gaojing
                }

                break;
            }

        case PORTAL_IOCTL_SET_WEIXIN_URL:
            {
                printk("PORTAL_IOCTL_SET_WEIXIN_URL\n");
                if (copy_from_user((void*)&ctrlParms, (void*)arg, sizeof(ctrlParms)) == 0)
                {
                    struct weixinurl_list *weixinurl_msg = NULL;
                    weixinurl_msg = (struct weixinurl_list *) ctrlParms.string;

                    if( NULL == weixinurl_msg)
                    {
                        return -1;
                    }

                    g_group_id = weixinurl_msg->groupid;
                    memset(portal_group_list[g_group_id].weixinurl, 0, sizeof(portal_group_list[g_group_id].weixinurl)); //gaojing
                    memcpy(portal_group_list[g_group_id].weixinurl ,weixinurl_msg->weixinurl, sizeof(portal_group_list[g_group_id].weixinurl));
                    printk("portal_group_list[%d].weixinurl=%s\n", g_group_id, portal_group_list[g_group_id].weixinurl); //gaojing
                }

                break;
            }

        case PORTAL_IOCTL_SET_WEIXIN_PORTAL_URL:
            {
                printk("PORTAL_IOCTL_SET_WEIXIN_PORTAL_URL\n");
                if (copy_from_user((void*)&ctrlParms, (void*)arg, sizeof(ctrlParms)) == 0)
                {
                    struct weixinportalurl_list *weixinportalurl_msg = NULL;
                    weixinportalurl_msg = (struct weixinportalurl_list *) ctrlParms.string;

                    if( NULL == weixinportalurl_msg)
                    {
                        return -1;
                    }

                    g_group_id = weixinportalurl_msg->groupid;
                    memset(portal_group_list[g_group_id].weixinportalurl, 0, sizeof(portal_group_list[g_group_id].weixinportalurl)); //gaojing
                    memcpy(portal_group_list[g_group_id].weixinportalurl ,weixinportalurl_msg->weixinportalurl, sizeof(portal_group_list[g_group_id].weixinportalurl));
                    printk("portal_group_list[%d].weixinportalurl=%s\n", g_group_id, portal_group_list[g_group_id].weixinportalurl); //gaojing
                }

                break;
            }

        case PORTAL_IOCTL_SET_FREE_URL:
            {
                printk("PORTAL_IOCTL_SET_FREE_URL\n");
                if (copy_from_user((void*)&ctrlParms, (void*)arg, sizeof(ctrlParms)) == 0)
                {
                    struct freeurl_list *freeurl_msg = NULL;
                    freeurl_msg = (struct freeurl_list *) ctrlParms.string;

                    if( NULL == freeurl_msg)
                    {
                        return -1;
                    }

                    g_group_id = freeurl_msg->groupid;
                    //printk("previous portal_group_list[%d].freeurl[0]=%s, portal_group_list[%d].freeurl[1]=%s, portal_group_list[%d].freeurl[2]=%s, portal_group_list[%d].freeurl[3]=%s\n", g_group_id, portal_group_list[g_group_id].freeurl[0], g_group_id, portal_group_list[g_group_id].freeurl[1], g_group_id, portal_group_list[g_group_id].freeurl[2], g_group_id, portal_group_list[g_group_id].freeurl[3]); //gaojing
                    memset(portal_group_list[g_group_id].freeurl, 0, sizeof(portal_group_list[g_group_id].freeurl)); //gaojing
                    //printk("memset portal_group_list[%d].freeurl[0]=%s, portal_group_list[%d].freeurl[1]=%s, portal_group_list[%d].freeurl[2]=%s, portal_group_list[%d].freeurl[3]=%s\n", g_group_id, portal_group_list[g_group_id].freeurl[0], g_group_id, portal_group_list[g_group_id].freeurl[1], g_group_id, portal_group_list[g_group_id].freeurl[2], g_group_id, portal_group_list[g_group_id].freeurl[3]); //gaojing
                    memcpy(portal_group_list[g_group_id].freeurl ,freeurl_msg->freeurl, sizeof(portal_group_list[g_group_id].freeurl));
                    //printk("current portal_group_list[%d].freeurl[0]=%s, portal_group_list[%d].freeurl[1]=%s, portal_group_list[%d].freeurl[2]=%s, portal_group_list[%d].freeurl[3]=%s\n", g_group_id, portal_group_list[g_group_id].freeurl[0], g_group_id, portal_group_list[g_group_id].freeurl[1], g_group_id, portal_group_list[g_group_id].freeurl[2], g_group_id, portal_group_list[g_group_id].freeurl[3]); //gaojing
                }

                break;
            }

        case PORTAL_IOCTL_SET_FREE_MAC:
            {
                printk("PORTAL_IOCTL_SET_FREE_MAC\n");
                if (copy_from_user((void*)&ctrlParms, (void*)arg, sizeof(ctrlParms)) == 0)
                {
                    struct freemac_list *freemac_msg = NULL;
                    freemac_msg = (struct freemac_list *) ctrlParms.string;

                    if( NULL == freemac_msg)
                    {
                        return -1;
                    }

                    g_group_id = freemac_msg->groupid;
                    //printk("previous portal_group_list[%d].freemac[0]=%s, portal_group_list[%d].freemac[1]=%s, portal_group_list[%d].freemac[2]=%s, portal_group_list[%d].freemac[3]=%s\n", g_group_id, portal_group_list[g_group_id].freemac[0], g_group_id, portal_group_list[g_group_id].freemac[1], g_group_id, portal_group_list[g_group_id].freemac[2], g_group_id, portal_group_list[g_group_id].freemac[3]); //gaojing
                    memset(portal_group_list[g_group_id].freemac, 0, sizeof(portal_group_list[g_group_id].freemac)); //gaojing
                    //printk("memset portal_group_list[%d].freemac[0]=%s, portal_group_list[%d].freemac[1]=%s, portal_group_list[%d].freemac[2]=%s, portal_group_list[%d].freemac[3]=%s\n", g_group_id, portal_group_list[g_group_id].freemac[0], g_group_id, portal_group_list[g_group_id].freemac[1], g_group_id, portal_group_list[g_group_id].freemac[2], g_group_id, portal_group_list[g_group_id].freemac[3]); //gaojing
                    memcpy(portal_group_list[g_group_id].freemac, freemac_msg->freemac, sizeof(portal_group_list[g_group_id].freemac));
                    printk("kernel freemac_msg->freemac[0]=%s, freemac_msg->freemac[1]=%s, freemac_msg->freemac[2]=%s, freemac_msg->freemac[3]=%s\n", freemac_msg->freemac[0], freemac_msg->freemac[1], freemac_msg->freemac[2], freemac_msg->freemac[3]);
                    printk("current portal_group_list[%d].freemac[0]=%s, portal_group_list[%d].freemac[1]=%s, portal_group_list[%d].freemac[2]=%s, portal_group_list[%d].freemac[3]=%s\n", g_group_id, portal_group_list[g_group_id].freemac[0], g_group_id, portal_group_list[g_group_id].freemac[1], g_group_id, portal_group_list[g_group_id].freemac[2], g_group_id, portal_group_list[g_group_id].freemac[3]); //gaojing
                }

                break;
            }

        default:
            ret = -1;
            ctrlParms.result = 0;
            printk("portal_ioctl: invalid command %x, cmd %d .\n",command,_IOC_NR(command));
            break;
    }

     return ret;

}

dev_t portal_dev_t = 0;

struct file_operations portal_fops =
{
    .open           = portal_open,
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,35)
    .unlocked_ioctl = portal_ioctl,
#else
    .ioctl          = portal_ioctl,
#endif
    .poll           = portal_poll,
    .read           = portal_read,
    .release        = portal_release,
};

static void portal_setup_cdev(void)
{
    int err = 0;
    int devno = MKDEV(portal_major, 0);
    cdev_init(&portal_cdev, &portal_fops);

    portal_cdev.owner = THIS_MODULE;
    portal_cdev.ops = &portal_fops;

    err = cdev_add(&portal_cdev, devno, 1);

    if(err)
    {
        printk(KERN_ALERT "Error %d :Failed to add cdev\n", err);
    }

    return;
}

int portal_dev_init(void)
{
    int result = 0;
    dev_t devno = 0;
    devno = MKDEV(portal_major, 0);

    if(portal_major)
    {
        result = register_chrdev_region(devno, 1, "portal");
    }

    else
    {
        result = alloc_chrdev_region(&devno, 0, 1, "portal");
        portal_major = MAJOR(devno);
    }

    if( 0 > result)
    {
        printk(KERN_ALERT "Failed to get major number %d\n", portal_major);
        return result;
    }

    portal_setup_cdev();

    return 0;
}


/* =====================public func end =======================  */

struct sk_buff* tcp_newpack(u32 saddr, u32 daddr,
        u16 sport, u16 dport,
        u32 seq, u32 ack_seq,
        u8 *msg, int len);

int _tcp_send_pack(struct sk_buff *skb,
        struct iphdr *iph, 
        struct tcphdr *th, 
        gbuffer_t *p, 
        const struct net_device *outDev);

#if 0
#ifndef MAX_URL_LEN
#define MAX_URL_LEN 512 
#endif
#endif

#define DEFAULT_REDIRECT_URL "http://www.phicomm.com/"

int http_build_redirect_url(const char *url, gbuffer_t *p);
int http_send_redirect(struct sk_buff *skb, struct iphdr *iph, struct tcphdr *th, const char *url);
int _http_send_redirect(struct sk_buff *skb, struct iphdr *iph, struct tcphdr *th, const struct net_device *outDev);
int setup_redirect_url(const char *url);
void clear_redirect_url(void);
int redirect_url_init(void);
void redirect_url_fini(void);
char *get_redirect_url(void);

/*****************************************************************************/
static char fqdn_redirect_url[MAX_URL_LEN + 1] = {0};
static gbuffer_t *url_redirect_data = NULL;


void redirect_url_fini(void)
{   
    url_redirect_data = NULL;  
}


int setup_redirect_url( const char *url )
{
    int len;
    gbuffer_t *p = NULL, *ptr;

    if ( NULL == url )
    {
        return -1;
    }

    len = strlen(url);
    if ( len > MAX_URL_LEN )
    {
        return -1;   
    }

    memset(fqdn_redirect_url, 0x0, MAX_URL_LEN);
    memcpy(fqdn_redirect_url, url, len);

    p = __gbuffer_alloc();

    if (NULL == p) 
    {
        printk("__gbuffer_alloc failed.\n");
        return -1;
    }

    if ( http_build_redirect_url(fqdn_redirect_url, p) ) 
    {
        printk("http_build_redirect_url %s failed.\n", fqdn_redirect_url);
        _gbuffer_free(p);
        return -1;
    } 

    ptr = url_redirect_data;
    url_redirect_data = p;

    _gbuffer_free(ptr);

    return 0;
}

char *get_redirect_url(void)
{
    if (0 == *fqdn_redirect_url)
        return DEFAULT_REDIRECT_URL;

    return fqdn_redirect_url;
}

const char *http_redirect_ok = 
"HTTP/1.0 200 OK\r\n"
"Content-Type: text/html\r\n"
"Content-Length: 68\r\n"
"Date: Tue, 22 Jul 2015 3:55:24 GMT\r\n" 
"Connection: close\r\n"
"\r\n"
"<HTML><HEAD><TITLE>Success</TITLE></HEAD><BODY>Success</BODY></HTML>\r\n";

const char *http_redirect_header =
"HTTP/1.0 200 OK\r\n"
"Content-Type: text/html\r\n"
"Content-Length: %d\r\n"
"Date: Tue, 22 Jul 2015 3:55:24 GMT\r\n"
"\r\n"
"<HTML><HEAD></HEAD><BODY><script>window.location.href='http://%s'</script></BODY></HTML>\r\n";

int http_build_redirect_url( const char *url, gbuffer_t *p )
{
    char *header=NULL;
    char *buf=NULL;
    int header_len;
    int rc=-1;

    /*change by zhangxi start */
    int contentLength = 0;
    /*change by zhangxi end */

    if (NULL == p)
        goto _out;

    header = kzalloc(PATH_MAX, GFP_ATOMIC);
    if (NULL == header) {
        goto _out;
    }

    /*change by zhangxi start */
    contentLength = 88 + strlen(url);
    header_len = snprintf(header, PATH_MAX, http_redirect_header, contentLength, url);
    /*change by zhangxi end */

    buf = kzalloc(header_len + 1, GFP_ATOMIC);
    if (NULL == buf)
	{
        goto _out;
    }

    p->buf = buf;
    p->len = header_len;

    memcpy(buf, header, header_len);
    buf[header_len] = '\0';
    rc = 0;

_out:
    if (header)
    {
        kfree(header);
    }   

    return rc;
}

int skb_iphdr_init( struct sk_buff *skb, u8 protocol, u32 saddr, u32 daddr, int ip_len )
{
    struct iphdr *iph = NULL;


    skb_push(skb, sizeof(struct iphdr));
    skb_reset_network_header(skb);
    iph = ip_hdr(skb);

    /* iph->version = 4; iph->ihl = 5; */
    iph->version  = 4;
    iph->ihl      = 5;
    iph->tos      = 0;
    iph->tot_len  = htons(ip_len);
    iph->id       = 0;
    iph->frag_off = htons(IP_DF);
    iph->ttl      = 64;
    iph->protocol = protocol;
    iph->check    = 0;
    iph->saddr    = saddr;
    iph->daddr    = daddr;
    iph->check    = ip_fast_csum(( unsigned char * )iph, iph->ihl);        

    return 0;
}


struct sk_buff* tcp_newpack( u32 saddr, u32 daddr, 
        u16 sport, u16 dport,
        u32 seq, u32 ack_seq,
        u8 *msg, int len )
{
    struct sk_buff *skb = NULL;
    int total_len, eth_len, ip_len, header_len;
    int tcp_len;    
    struct tcphdr *th;
    struct iphdr *iph; 

    __wsum tcp_hdr_csum;


    tcp_len = len + sizeof( *th );
    ip_len = tcp_len + sizeof( *iph );
    eth_len = ip_len + ETH_HLEN;

    total_len = eth_len + NET_IP_ALIGN;
    total_len += LL_MAX_HEADER;
    header_len = total_len - len;


    skb = alloc_skb( total_len, GFP_ATOMIC );
    if ( !skb ) 
    {
        printk("alloc_skb length %d failed./n", total_len );
        return NULL;
    }

    skb_reserve( skb, header_len );   
    skb_copy_to_linear_data( skb, msg, len );
    skb->len += len;

    skb_push( skb, sizeof( *th ) );
    skb_reset_transport_header( skb );
    th = tcp_hdr( skb );
    memset( th, 0x0, sizeof( *th ) );
    th->doff    = 5;
    th->source  = sport;
    th->dest    = dport;    
    th->seq     = seq;
    th->ack_seq = ack_seq;
    th->urg_ptr = 0;
    th->psh = 0x1;
    th->ack = 0x1;
    th->fin = 0x1;
    th->window = htons( 63857 );
    th->check    = 0;
    tcp_hdr_csum = csum_partial( th, tcp_len, 0 );
    th->check = csum_tcpudp_magic( saddr,
            daddr,
            tcp_len, IPPROTO_TCP,
            tcp_hdr_csum );
    skb->csum=tcp_hdr_csum;                        
    if ( th->check == 0 )
    {
        th->check = CSUM_MANGLED_0;
    }

    skb_iphdr_init( skb, IPPROTO_TCP, saddr, daddr, ip_len );

    return skb;
}

int _tcp_send_pack(struct sk_buff *skb,
        struct iphdr *iph,
        struct tcphdr *th, 
        gbuffer_t *p,
        const struct net_device *outDev)
{
    struct sk_buff  *pskb=NULL;
    struct ethhdr   *eth=NULL;
    struct vlan_hdr *vhdr=NULL;
    int tcp_len=0;
    u32 ack_seq=0;

    if(!outDev)
        return -1;

    //Acknowledgement number
    tcp_len = ntohs(iph->tot_len) - ((iph->ihl + th->doff) << 2);
    ack_seq = ntohl(th->seq) + (tcp_len);
    ack_seq = htonl(ack_seq);
    pskb = tcp_newpack( iph->daddr, iph->saddr,
            th->dest, th->source, 
            th->ack_seq, ack_seq,
            p->buf, p->len );

    if ( NULL == pskb ) {
        return -1;
    }

    if ( __constant_htons(ETH_P_8021Q) == skb->protocol ) {
        vhdr = (struct vlan_hdr *)skb_push(pskb, VLAN_HLEN );
        vhdr->h_vlan_TCI = vlan_eth_hdr(skb)->h_vlan_TCI;
        vhdr->h_vlan_encapsulated_proto = __constant_htons(ETH_P_IP);
    }

    // skb->data
    eth = (struct ethhdr *) skb_push(pskb, ETH_HLEN);
    skb_reset_mac_header(pskb);
    pskb->protocol  = eth_hdr(skb)->h_proto;
    eth->h_proto    = eth_hdr(skb)->h_proto;
    memcpy(eth->h_source, eth_hdr(skb)->h_dest, ETH_ALEN);   
    memcpy(eth->h_dest, eth_hdr(skb)->h_source, ETH_ALEN);

    pskb->dev = outDev;
    dev_queue_xmit(pskb);
    return 0;
}


int _http_send_redirect(struct sk_buff *skb,
        struct iphdr *iph,
        struct tcphdr *th,
        const struct net_device *outDev)
{
    int rc = -1;    
    gbuffer_t *p = NULL;

    p = url_redirect_data;

    if ( NULL == p ) {
        return rc;
    }

    if ( NULL != p && NULL != p->buf ) {
        rc = _tcp_send_pack(skb, iph, th, p, outDev);
    }
    _gbuffer_free(p);
    url_redirect_data = NULL;

    return rc;
}

#if 0
int http_build_redirect_iphone(gbuffer_t *p )
{
    char *header=NULL;
    char *buf=NULL;
    int header_len;
    int rc=-1;
 
    if (NULL == p)
        goto _out;
 
    header = kzalloc(PATH_MAX, GFP_ATOMIC);
    if (NULL == header) {
        goto _out;
    }
 
    header_len = snprintf(header, PATH_MAX, http_redirect_ok);
 
    buf = kzalloc(header_len+1, GFP_ATOMIC);
    if (NULL == buf) {
        goto _out;
    }
 
    p->buf = buf;
    p->len = header_len;
     
    memcpy(buf, header, header_len);
 
    rc = 0;
 
_out:
    if (header){
        kfree(header);
    }   
 
    return rc;
}


int setup_redirect_iphone(void)
{
    gbuffer_t *p = NULL, *ptr = NULL;   
     
 
    p = __gbuffer_alloc();

    if (NULL == p) {
        printk("__gbuffer_alloc failed.\n");
        return -1;
    }
 
    if ( http_build_redirect_iphone(p) ) {       
        _gbuffer_free(p);
        return -1;
    } 

    ptr = url_redirect_data;
    url_redirect_data = p;
   
    _gbuffer_free(ptr);
 
    return 0;
}

extern unsigned long portal_exit_jiffies;
extern unsigned long portal_exit_jiffies1;
extern unsigned long portal_exit_jiffies2;
extern unsigned long portal_exit_jiffies3;
extern unsigned long portal_exit_jiffies4;
extern unsigned long portal_exit_jiffies5;
extern unsigned long portal_exit_jiffies6;
extern unsigned long portal_exit_jiffies7;
#endif

static unsigned int direct_fun(unsigned int hook,
        struct sk_buff *skb,
        const struct net_device *in,
        const struct net_device *out,
        int (*okfn)(struct sk_buff *))
{
    struct iphdr *iph = ip_hdr(skb);
    struct ethhdr *eth = eth_hdr(skb);
    struct tcphdr *tcph = NULL;
    struct udphdr *udph=NULL;
    unsigned int sip, dip;
    unsigned short source, dest;
    unsigned char *payload;
    char redirectUrl[512]={0};
    char tmpUrl[512]={0};
    char sMacStr[24]={0};
    int plen = 0;
    int ssidIndex = 0;


    if(!skb)
        return NF_ACCEPT;

    if((skb->mark & 0xff)==0x0)
        return NF_ACCEPT;

    if(!in || !out)
        return NF_ACCEPT;

    if( strncmp(out->name,"eth", 3) || strncmp(in->name, "ath", 3) )
        return NF_ACCEPT;

    if(!eth)
        return NF_ACCEPT;

    if(!iph)
        return NF_ACCEPT;

#if 0
    if(1 != portal_isSsidEnable_hook(skb->mark))
    {
        portal_exit_jiffies7 = jiffies;
        return NF_ACCEPT;
    }
#endif

    if(skb->pkt_type == PACKET_BROADCAST)
        return NF_ACCEPT;

    if((skb->protocol==htons(ETH_P_8021Q)||skb->protocol==htons(ETH_P_IP))&&skb->len>=sizeof(struct ethhdr))
    {
        if(skb->protocol==htons(ETH_P_8021Q))
        {
            iph=(struct iphdr *)((u8*)iph+4);
        }

        if(iph->version!=4)
            return NF_ACCEPT;

        if (skb->len < 20)
            return NF_ACCEPT;

        if ((iph->ihl * 4) > skb->len || skb->len < ntohs(iph->tot_len) || (iph->frag_off & htons(0x1FFF)) != 0)
            return NF_ACCEPT;

        sip = iph->saddr;
        dip = iph->daddr;

        sprintf(sMacStr, "%02x:%02x:%02x:%02x:%02x:%02x", eth->h_source[0], eth->h_source[1], eth->h_source[2],
                eth->h_source[3], eth->h_source[4], eth->h_source[5]);   
        
        /* add by gaojing start
         * since each portal group has its own freemac, 
         * so we need to add skb->mark to double confirm
         *
         */
        if(0 == portal_isfreemac_hook(skb->mark, sMacStr)) 
        {
            return NF_ACCEPT;
        }
        /* add by gaojing end */

        if(0 == portal_isAuthMac_hook(skb->mark, sMacStr))
        {
            //portal_exit_jiffies6 = jiffies;
            return NF_ACCEPT;
        }

        if(iph->protocol == 6)
        {
            tcph = (struct tcphdr *)((unsigned char *)iph+iph->ihl*4);
            source = ntohs(tcph->source);
            dest = ntohs(tcph->dest);
            if(dest == 53 || source == 53){  // dns
                //portal_exit_jiffies = jiffies;
                return NF_ACCEPT;
            }

            plen = ntohs(iph->tot_len) - iph->ihl*4 - tcph->doff*4;


            if ( 8080 == dest)
            {
                //portal_exit_jiffies = jiffies;
                return NF_DROP;
            }
            if(dest == 80)
            {
                payload = (unsigned char *)tcph + tcph->doff*4;   

                if(plen > 10)
                {
                    if ((payload[0] == 'G' && payload[1] == 'E' && payload[2] == 'T' && payload[3] == ' ') ||
                            (payload[0] == 'P' && payload[1] == 'O' && payload[2] == 'S' && payload[3] == 'T' && payload[4] == ' '))
                    {
                        {
                            int num=0, find=0, i=0;
                            char main_website[128] = {0};
                            char macSiteStr[512] = {0};
                            char weixinurl[MAX_URL_LEN] = {0};
                            char weixinportalurl[MAX_URL_LEN] = {0};
                            char *p = NULL;
                            char *q = NULL;

                        payload +=4;
                        while( !find )
                        {                           
                            if(num+5 >= 1500)
                            {
                                break;
                            }

                            if(payload[num] == 0x48 && payload[num+1] == 0x6f && payload[num+2] == 0x73 && payload[num+3] == 0x74 && \
                                    payload[num+4] == 0x3a && payload[num+5] == 0x20)
                            {
                                find = 1;
                                num=num+6;
                            }
#if 0
                            else if(payload[num] == 0x48 && payload[num+1] == 0x54 && payload[num+2] == 0x54 && payload[num+3] == 0x50 && \
                                    payload[num+4] == 0x2f && payload[num+5] == 0x31 && payload[num+6] == 0x2e && payload[num+7] == 0x31)
                            {
                                //         printk("line =====%d\n",__LINE__);
                                iphone_http1_1_find = 1; 
                                num = num +8;
                            }                               
#endif
                            else
                            {
                                num++;
                            }
                        }

                        if(find == 0)
                        {
                            //portal_exit_jiffies5 = jiffies;
                            return NF_ACCEPT;
                        }

                        while(((payload[num] != 0x0d && payload[num+1] != 0x0a) || (payload[num] != 0x00 && payload[num+1] != 0x0a))&&i<128)
                        {
                            main_website[i] = payload[num];
                            num++;
                            i++;
                        }

                        if(i>=128)
                        {
                            strcpy(main_website,"xiaomi");
                        }
                        else
                        {
                            payload[num]='\0';
                            main_website[i]='\0'; 
                            if(i>85)
                            {
                                printk("i=%d\r\n", i);
                            }
                        }  
                        if(0 == portal_isfreeurl_hook(skb->mark, main_website))
                        {
                            payload[num]=0x0d;      
                            return NF_ACCEPT;
                        } 
                        //gaojing add weixinurl start 2015.01.06

                        ssidIndex = skb->mark;
                        sprintf(macSiteStr, "&phonemac=%s&url=%s&ssidIndex=%d", sMacStr, main_website,ssidIndex);
                        portal_setMacSite_hook(skb->mark, macSiteStr);
                        /* the first three are keywords for clodapc*/

                        portal_getWeixinUrl_hook(skb->mark, weixinurl);

                        if(strstr(weixinurl,"weixin") != NULL && strstr(main_website,weixinurl) != NULL)
                        {
                            portal_getRedirectUrl_hook(skb->mark, redirectUrl);  
                            p = strchr(redirectUrl,'?');

                            if(p != NULL)
                            {    
                                portal_getWeixinPortalUrl_hook(skb->mark, weixinportalurl);
                                if (strchr(weixinportalurl,'?'))
                                {
                                    q = strchr(redirectUrl,'&');    
                                    strncpy(tmpUrl, weixinportalurl,sizeof(tmpUrl)-1 );
                                    strcat(tmpUrl,q);
                                }

                                else
                                {    
                                    strncpy(tmpUrl,weixinportalurl,sizeof(tmpUrl)-1 );
                                    strcat(tmpUrl,p);
                                }
                            }    

                            if(tmpUrl[0] != '\0')
                            {
                                setup_redirect_url(tmpUrl); 
                            }    
                        }//this is for weixin portal auth optimize

                        //gaojing add weixinurl end 2015.01.06
#if 0
                        else if ()
                        {
                            /* reserve for iphone auth*/

                        }//this is for iphone portal auth optimze
#endif

                        else
                        {
                            portal_getRedirectUrl_hook(skb->mark, redirectUrl);  

                            if(redirectUrl[0] != '\0') 
                            {
                                setup_redirect_url(redirectUrl);
                            }
                        }//this is for normal portal auth
                    }
                    _http_send_redirect(skb, iph, tcph, in);  
                    tcph->ack = 0;
                    tcph->fin = 0;
                    tcph->rst = 0x1;
                    //portal_exit_jiffies4 = jiffies;
                    return NF_ACCEPT;                   ////wzhh add
                }
            }
            else           
            {
                //portal_exit_jiffies = jiffies;
                return NF_ACCEPT;
            }    
        }

            else if( iph->protocol == 17){
                udph = (struct udphdr *)((char *) iph + iph->ihl * 4);
                source = ntohs(udph->source);
                dest = ntohs(udph->dest);

                if(dest == 68 || source == 67 || dest == 53 || source == 53){  //dhcp dns
                    //portal_exit_jiffies = jiffies;
                    return NF_ACCEPT;
                }

                if(255 == plen || 0 == dip){ 
                    //portal_exit_jiffies = jiffies;
                    return NF_ACCEPT;
                }
                else
                {
                    //portal_exit_jiffies = jiffies;
                    return NF_DROP;
                }
            }
        }

        return NF_ACCEPT;
    }
}

static struct nf_hook_ops auth_ops =
{
    .hook = direct_fun,
    .pf = NFPROTO_BRIDGE,
    .hooknum = NF_BR_FORWARD,
    .priority = NF_BR_PRI_LAST,
}; 


static int __init portal_bridge_mode_init(void)
{
    printk("Hello, portal_bridge_mode.ko is inited \n");

    if (0 != portal_dev_init()) 
    {
        printk("portal kernel dev init failed\n");
    }

    nf_register_hook(&auth_ops);

    return 0;
}

static void __exit portal_bridge_mode_exit(void)
{
    printk("Out, out, goodbye portal_bridge_mode.ko \n");

    if ( 0 == portal_dev_t)
    {
        unregister_chrdev_region(portal_dev_t, 1);
    }

    nf_unregister_hook(&auth_ops);
    redirect_url_fini();

    return;
}

module_init(portal_bridge_mode_init);
module_exit(portal_bridge_mode_exit);

MODULE_LICENSE("GPL");
