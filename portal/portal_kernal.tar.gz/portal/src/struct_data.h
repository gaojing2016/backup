
#define PORTAL_IOCTL_MAGIC       'Q'
#define PORTAL_IOCTL_GET_PORTAL_INFO                      _IOWR(PORTAL_IOCTL_MAGIC, 0, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_PORTAL_URL                      _IOWR(PORTAL_IOCTL_MAGIC, 1, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_FREE_URL                      _IOWR(PORTAL_IOCTL_MAGIC, 2, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_FREE_MAC                      _IOWR(PORTAL_IOCTL_MAGIC, 3, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_WEIXIN_URL                      _IOWR(PORTAL_IOCTL_MAGIC, 4, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_WEIXIN_PORTAL_URL                      _IOWR(PORTAL_IOCTL_MAGIC, 5, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_IPHONE_URL                      _IOWR(PORTAL_IOCTL_MAGIC, 6, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_PORTAL_INFO_UPDATE                      _IOWR(PORTAL_IOCTL_MAGIC, 7, PORTAL_IOCTL_PARMS)
#if 0
#define PORTAL_IOCTL_SET_FREE_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 55, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_PORTAL_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 56, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_FREE_MAC                         _IOWR(PORTAL_IOCTL_MAGIC, 57, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_NEW_AUTH_CLEINT_OBJ                         _IOWR(PORTAL_IOCTL_MAGIC, 58, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_LAN_IP_ADDRESS                         _IOWR(PORTAL_IOCTL_MAGIC, 59, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_DEL_AUTH_CLEINT_OBJ                         _IOWR(PORTAL_IOCTL_MAGIC, 60, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_SSID_PORTAL_ENABLE                        _IOWR(PORTAL_IOCTL_MAGIC, 63, PORTAL_IOCTL_PARMS)

#define PORTAL_IOCTL_GET_FREE_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 64, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_PORTAL_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 65, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_FREE_MAC                         _IOWR(PORTAL_IOCTL_MAGIC, 66, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_AUTH_CLEINT_OBJ                         _IOWR(PORTAL_IOCTL_MAGIC, 67, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_WEIXIN_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 68, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_WEIXIN_PORTAL_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 69, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_SSID_WEIXIN_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 79, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_SSID_WEIXIN_PORTAL_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 80, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_SSID_PORTAL_STATE                  _IOWR(PORTAL_IOCTL_MAGIC, 70, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_SET_IPHONE_FREE_URL                         _IOWR(PORTAL_IOCTL_MAGIC, 71, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_SSID_WEIXIN_URL                     _IOWR(PORTAL_IOCTL_MAGIC, 76, PORTAL_IOCTL_PARMS)
#define PORTAL_IOCTL_GET_SSID_WEIXIN_PORTAL_URL                _IOWR(PORTAL_IOCTL_MAGIC, 77, PORTAL_IOCTL_PARMS)
#endif

#define MAX_FREE_URL_LIST_NUM       128
#define MAX_FREE_MAC_LIST_NUM       30
#define MAX_IPHONE_URL_LIST_NUM     30
#define MAX_URL_LEN        256
#define MAX_MAC_LEN        18

#define LAN_DEV_NUM        2 

struct portal_group
{   
    char freeurl[MAX_FREE_URL_LIST_NUM][MAX_URL_LEN];         /* mark the freeurl in each portal group */
    char freemac[MAX_FREE_MAC_LIST_NUM][MAX_MAC_LEN];         /* mark the freemac in each portal group */
    char portalurl[MAX_URL_LEN];                              /* mark the portalurl in each portal group */
    char redirecturl[MAX_URL_LEN];                            /* reserve for iphone and weixin auth */
    char weixinportalurl[MAX_URL_LEN];
    char weixinurl[MAX_URL_LEN];
};  

char iphoneurl[MAX_IPHONE_URL_LIST_NUM][MAX_URL_LEN];

struct portal_info
{
    struct portal_group portal_group_list_info[LAN_DEV_NUM];
    char iphoneurl[MAX_IPHONE_URL_LIST_NUM][MAX_URL_LEN];
};

struct freeurl_list
{   
    int groupid;
    char freeurl[MAX_FREE_URL_LIST_NUM][MAX_URL_LEN];
};  

struct iphoneurl_list
{   
    char iphoneurl[MAX_IPHONE_URL_LIST_NUM][MAX_URL_LEN];
};  

struct freemac_list
{
    int groupid;
    char freemac[MAX_FREE_MAC_LIST_NUM][MAX_MAC_LEN];
};

struct portalurl_list
{
    int groupid;
    char portalurl[MAX_URL_LEN];
};


struct weixinurl_list
{
    int groupid;
    char weixinurl[MAX_URL_LEN];
};

struct weixinportalurl_list
{
    int groupid;
    char weixinportalurl[MAX_URL_LEN];
};

typedef enum
{
    PERSISTENT=0,
    NVRAM,
    PDTINFO,
    BCM_IMAGE_CFE,
    IMAGE_FS,
    IMAGE_KERNEL,
    IMAGE_WHOLE,
    USER_PAD,
    FLASH_SIZE,
    SET_CS_PARAM,
    BACKUP_PSI,
    SYSLOG,
    UBOOT_ENV
} PORTAL_IOCTL_ACTION;


typedef struct portalIoctParms
{
    char *string;
    char *buf;
    int strLen;
    int offset;
    PORTAL_IOCTL_ACTION  action;        /* flash read/write: nvram, persistent, bcm image */
    int result;
} PORTAL_IOCTL_PARMS;






